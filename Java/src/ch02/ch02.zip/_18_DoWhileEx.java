package ch02;

import java.util.Scanner;

public class _18_DoWhileEx {
	public static void main(String[] args) {
		// 메뉴선택 : q or Q or 글자수가 1글자를 만나면 '종료' 출력   
		
		
		//input.charAt(0); // 입력값의 첫글자
		//input.length() // 문자길이
		
		String i =""; 
		Scanner input = new Scanner(System.in);
		
		
		do {	
		System.out.println("글자 입력 : ");
		i = input.nextLine();
		
		
		
	
			
		}while()
		
		
	}

}
